package testcases;

import org.testng.annotations.Test;
import org.testng.annotations.AfterMethod;

public class TestClassB {
  
  @Test
  public void login() {
  
	  System.out.println("in login function ");
	  
  }
  
  @Test
  public void search() {
	  System.out.println("in serach function ");
	  
  }
  
  
  
  @AfterMethod
  public void afterMethod() {
  }

}
