package Testing.HybridProject;

import static org.junit.Assert.*;

import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFShapeTypes;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DataExample {

	String data[][] = null;
	WebDriver driver = null;
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

	
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	
		try {
			
			//read file 
			FileInputStream fs = new FileInputStream("C:\\Users\\NITS\\Desktop\\Desktop - Raman\\Techvision\\UserData.xls");
		
			//convert file to excel workbook
			HSSFWorkbook book = new HSSFWorkbook(fs);
			
			//read particular worksheet
			HSSFSheet sheet = book.getSheet("TestData");
			
			int sc,rc,cc;
			sc = book.getNumberOfSheets();
			rc = sheet.getPhysicalNumberOfRows();
			cc = sheet.getRow(0).getPhysicalNumberOfCells();
			
			System.out.println("sheet count "+sc);
			System.out.println("row count "+rc);
			System.out.println("col count "+cc);
		
			data = new String[rc][cc];
			
			for(int i=0; i<rc; i++) {
				
					HSSFRow row = sheet.getRow(i);
					
					HSSFCell cell = row.getCell(0);
					System.out.print(cell.getStringCellValue()+"\t");
					
			
					data[i][0] = cell.getStringCellValue();
					
					cell = row.getCell(1);
					System.out.print(cell.getStringCellValue()+"\t");
					data[i][1] = cell.getStringCellValue();
					
					
					cell = row.getCell(2);
					System.out.println(cell.getStringCellValue()+"\t");
					data[i][2] = cell.getStringCellValue();
					
			}
			
		}
		catch(Exception ex) {
			
			
		}
	
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
	
		
			
		driver = new ChromeDriver();
		
		//driver.get("http://erp.techvisionit.com/");
		
		for(int i=1; i<data.length;i++)
		{

			driver.get("http://erp.techvisionit.com/");
			
			driver.findElement(By.id("txtUserName")).clear();
				
			driver.findElement(By.id("txtUserName")).sendKeys(data[i][0]);
			
			driver.findElement(By.id("txtPassword")).clear();
			driver.findElement(By.id("txtPassword")).sendKeys(data[i][1]);
			
			driver.findElement(By.id("btnSubmit")).click();
			
		}
		
		
		//fail("Not yet implemented");
	
	}

}
