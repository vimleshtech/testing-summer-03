package junitexample;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestClass {

	public static void main(String[] a) {
		
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.naukri.com");
		
		//get ref of windows
		Set<String>  wins= 	driver.getWindowHandles();
		//Set<String>  : declartion of collection 
		
		System.out.println(wins.size()); //print count of windows
		
		for(String win:wins) {
			
			driver.switchTo().window(win);
			String title = driver.getTitle();
			//System.out.println(title);
		
			if(title.startsWith("Amazon")) {
				driver.findElement(By.xpath("/html/body/a")).click();
			}
			
		}
		
		
		
		
	}
}
