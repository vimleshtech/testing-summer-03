package junitexample;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.Assert;

public class testcase {

	//declare global variable 
	static WebDriver driver = null;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		//Allocate the memory of driver 
		driver = new ChromeDriver();
		//open the site
		driver.get("https://www.w3schools.com/js/tryit.asp?filename=tryjs_alert");
	
	}
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	
		//quit the browser 
		driver.quit();
		
	}


	@Test
	public void test() {
		
		//iframe 
		driver.switchTo().frame(0);
		String s = driver.getPageSource();
		//System.out.println(s);
		
		driver.findElement(By.xpath("/html/body/button")).click();
		
		//read message 
		boolean isAlert=false;
		try {
			String msg = driver.switchTo().alert().getText();
			System.out.println(msg);
			driver.switchTo().alert().dismiss();
		
			isAlert=true;
		}
		catch (Exception e) {
			// TODO: handle exception
			isAlert=false;
		}
		
		Assert.assertEquals(true, isAlert);
		
	}

}
