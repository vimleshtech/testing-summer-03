package junitexample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertHandling {

	public static void main(String[] args) {

		WebDriver driver = new ChromeDriver();
		driver.get("https://www.w3schools.com/js/tryit.asp?filename=tryjs_alert");
		
		//iframe 
		driver.switchTo().frame(0);
		String s = driver.getPageSource();
		//System.out.println(s);
		
		driver.findElement(By.xpath("/html/body/button")).click();
		
		//read message 
		String msg = driver.switchTo().alert().getText();
		System.out.println(msg);
		driver.switchTo().alert().dismiss();
	}

}
