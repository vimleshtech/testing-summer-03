package pagefactory;

public class HomePage {

}
