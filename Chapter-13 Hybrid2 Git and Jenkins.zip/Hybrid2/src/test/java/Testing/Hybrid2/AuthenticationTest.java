package Testing.Hybrid2;

import java.io.IOException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import abstracts.AbstractLogin;
import pageobjects.LoginPage;
import reports.CustomReport;

public class AuthenticationTest {


	static WebDriver driver = null;
	AbstractLogin login = null;

	boolean isPageFactory = true;
	
	static CustomReport report = null;
	
	@BeforeClass
	public static void beforeClass() {
		
		driver =  new ChromeDriver();
		driver.get("http://erp.techvisionit.com/");
	
		report = new CustomReport();
		
	}
	
	@AfterClass
	public static void afterClass() throws IOException {
		
		report.saveReport();
		
	}
	@Test
	public void testLogin() {
		
		if(isPageFactory )
			login = new pagefactory.LoginPage(driver);
		else
			login = new pageobjects.LoginPage(driver);
			
		login.login("monika", "tgkjhfjhf");
		
		
		report.testCaseStatus("testLogin", "pass");
		
	}


	@Test
	public void testSearch() {
	
		report.testCaseStatus("testSearch", "pass");
		
		System.out.println("all test case executed..");
	}

	@Test
	public void testLogout() {
	
		try {
		int n=444/0;
		
		report.testCaseStatus("testLogout", "pass");
		
		}
		catch (Exception e) {
			// TODO: handle exception
			report.testCaseStatus("testLogout", "fail");
			
		}
	}
	
}
