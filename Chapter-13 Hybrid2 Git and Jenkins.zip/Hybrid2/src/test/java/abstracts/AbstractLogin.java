package abstracts;

public abstract class AbstractLogin {

	

	public abstract void login(String uname, String pwd);
	
		
}
