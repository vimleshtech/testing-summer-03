package reports;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class CustomReport {

	
	String str="";
	public CustomReport(){
	
		str ="<html>\r\n" + 
				"		<body bgcolor='lime'>\r\n" + 
				"			<table width='100%' border='2'>\r\n" + 
				"			<tr>\r\n" + 
				"			<th>\r\n" + 
				"				TestCase\r\n" + 
				"			</th>\r\n" + 
				"			<th>\r\n" + 
				"				Status\r\n" + 
				"			</th\r\n" + 
				"			</tr>";
		
		
		
		
	}
	public void testCaseStatus(String tname, String status) {
		
		str+="<tr><td>"+tname+ " </td> <td> "+ status+"</td> </tr>";
	}
	public void saveReport() throws IOException {
		
		str+= "			</table>\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"		</body>\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"		</html>\r\n" + 
				"";
		
		
		FileWriter writer = new FileWriter("C:\\Users\\NITS\\Desktop\\myreport.htm");
		BufferedWriter bw  = new BufferedWriter(writer);
		bw.write(str);
		bw.close();
		writer.close();
		
	}
	
}
