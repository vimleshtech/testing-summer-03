package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import abstracts.AbstractLogin;

public class LoginPage extends AbstractLogin {

	
	WebDriver driver = null;
		
	By userName = 	By.name("txtUserName");
	By userPwd = 	By.name("txtPassword");
	By btnLogin = 	By.id("btnSubmit");
		
	public LoginPage (WebDriver driver){
		
		this.driver = driver;
		
	}
	
	public void login(String uname, String pwd) {
		
		driver.findElement(userName).sendKeys(uname);
		driver.findElement(userPwd).sendKeys(pwd);
		driver.findElement(btnLogin).click();
		
	}
	
	public void resetPwd(String uname) {
		
		driver.findElement(userName).sendKeys(uname);
		
		driver.findElement(btnLogin).click();
		
	}
	
}
