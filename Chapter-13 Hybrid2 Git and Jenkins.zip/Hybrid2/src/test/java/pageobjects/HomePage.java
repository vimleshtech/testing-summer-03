package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {


	WebDriver driver = null;
		
	By userName = 	By.id("txtUserName");
	By userPwd = 	By.xpath("txtPassword");
	By btnLogin = 	By.name("btnSubmit");
	By btnLogin1 = 	By.name("btnSubmit");
	By btnLogin2 = 	By.name("btnSubmit");
	By btnLogin3 = 	By.name("btnSubmit");
	By btnLogin4 = 	By.name("btnSubmit");
	By btnLogin5 = 	By.name("btnSubmit");
	By btnLogin7 = 	By.name("btnSubmit");
	By btnLogin9 = 	By.name("btnSubmit");
	By btnLogin50= 	By.name("btnSubmit");

	HomePage (WebDriver driver){
		this.driver = driver;
	}
}
