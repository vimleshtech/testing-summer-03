package erp.testcases;

import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import utils.ReadProperties;

public class ERPAutomation {
	
	Properties prop = null;
	WebDriver driver = null;
	
	private final static Logger logger = Logger.getLogger(ERPAutomation.class);
	
	@Test
	public void login() {
	  		
		
		
		logger.info("in login test");
		//read data from props 
		System.out.println(prop.getProperty("url"));
		System.out.println(prop.getProperty("uid"));
		System.out.println(prop.getProperty("pwd"));
		System.out.println(prop.getProperty("btnlogin"));
		
		//driver.get(prop.getProperty("url"));
		//driver.findElement(By.id("uid"));
		logger.info("login test is completed");
				
	}
  
	@Test
	public void beforeTest() throws IOException {
	  
		logger.info("in beforetest function");
		prop  = utils.ReadProperties.getProperties(); //get all prpoperties
		//driver = new ChromeDriver();
		logger.info("in beforetest function is executed");
	}
}
