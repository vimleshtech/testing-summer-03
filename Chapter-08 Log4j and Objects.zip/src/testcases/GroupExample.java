package testcases;

import org.testng.annotations.Test;

public class GroupExample {
	//now we will create three groups : 1. authentication 2. search 3. payment
  @Test(groups= {"authentication"})
  public void login() {
	  
	  System.out.println("login -");
  }
  @Test(groups= {"authentication"})
  public void forgotPwd() {
	  
	  System.out.println("forgot pwd -");
  }
  
  @Test(groups= {"search"})
  public void SearchByColor() {
	  System.out.println("search by color -");
  }
  
  @Test(groups= {"search"})
  public void SearchBySize() {
	  System.out.println("search by size -");
  }
  
  @Test(groups= {"search"})
  public void SearchByBrand() {
	  System.out.println("search by brand -");
  }
  
  @Test(groups= {"authentication"})
  public void logout() {
	  
	  System.out.println("logout -");
  }
  
  @Test(groups= {"payment"})
  public void placeOrder() {
	  System.out.println("placeorder-");
  }
  
  
  @Test(groups= {"payment"})
  public void makePayment() {
	  System.out.println("makePayment -");
  }
  
}
