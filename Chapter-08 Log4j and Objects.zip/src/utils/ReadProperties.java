package utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

//import class
import org.apache.log4j.Logger;


public class ReadProperties {

	//create object 
	private final static Logger logger = Logger.getLogger(ReadProperties.class);
	
	public static Properties getProperties() throws IOException {
			
		//write message 
		logger.info("in getProperties function");
		
		Properties prop = new Properties();
		
		try {
			//read file from physical location 
			FileInputStream fs  = new FileInputStream(":\\Users\\vkumar15\\eclipse\\TestApp\\src\\objects\\Objects.properties");
					
			//Properties  : is inbuilt of java 
			
			prop.load(fs);
			
		}
		catch (Exception e) {
			//write message
			logger.error(e);
		}
		
		//write message
		logger.info("in getProperties function is executed");
		return prop;
		
	}
	
}
