package testcase2;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

public class DPExample {
	
	@BeforeTest
	public void beforeTest() {
		//driver = new ChromeDriver();
	}
  @Test(dataProvider = "dp")
  public void Register(String name, String gender, int age) {
	  	  
	  System.out.println(name+"\t"+gender+"\t"+age);
  }
  
  //Object : is inbuilt class which can hold any type of data
  //[][] - array
  
  @DataProvider
  public Object[][] dp() {	  
	  
	  return new Object[][] {
    	
		      new Object[] { "Nitin", "male",23 },
		      new Object[] { "Raman", "male",30 },
		      new Object[] { "Monika", "female",27 },
		      new Object[] { "Divya", "female",18 },
		      new Object[] { "Kshitz", "male",29 },
	  };
    
    
  }
}
