package testcases;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class TestClassA {
  @Test
  public void f() {
  
  
	  System.out.println("in f function ");
	  
	  
  }
 
  @Test(priority=1)
  public void div() {
  
  
	  int a,b,c;
	  a =55;
	  b =0;
	  c =a/b;
	  System.out.println("out "+c);
	  
	  
  }
  
  @Test(dependsOnMethods= {"div"},priority=2)
  public void logout() {
  
	  System.out.println("logout");
  }
  @BeforeMethod
  public void beforeMethod() {
  }

  @AfterMethod
  public void afterMethod() {
  }

  @BeforeClass
  public void beforeClass() {
  }

  @AfterClass
  public void afterClass() {
  }

  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }

  @BeforeSuite
  public void beforeSuite() {
  }

  @AfterSuite
  public void afterSuite() {
  }

}
