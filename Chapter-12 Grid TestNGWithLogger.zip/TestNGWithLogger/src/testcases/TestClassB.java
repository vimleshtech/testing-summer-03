package testcases;

import org.openqa.selenium.remote.RemoteWebDriver; //hub
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities; //dynamic or multiple browser 


import java.net.URL;	//cross system connection 
import java.util.concurrent.TimeUnit; 
import java.net.MalformedURLException;


import org.testng.annotations.Test;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

public class TestClassB {

	
  WebDriver driver = null;
	
  @Test
  public void login() {
  
	  
	  String t = driver.getCurrentUrl();
	  System.out.println(t);
	  
	  
	  t = driver.getTitle();
	  System.out.println(t);
	  
	  System.out.println("in login function ");
	  
  }
  
  @Test
  public void search() {
	  System.out.println("in serach function ");
	  
  }
  

  @Parameters("browser")
  @BeforeTest
  public void beforeTest(String browser) throws MalformedURLException {
	  
	  String URL = "http://www.calculator.net";	
      
      if (browser.equalsIgnoreCase("firefox"))
      {
         //System.out.println(" Executing on FireFox");
         
         String Node = "http://192.168.0.101:5555/wd/hub";
         DesiredCapabilities cap = DesiredCapabilities.firefox();
         cap.setBrowserName("firefox");
         
         driver = new RemoteWebDriver(new URL(Node), cap);
         // Puts an Implicit wait, Will wait for 10 seconds before throwing exception
         driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
         
         // Launch website
         driver.navigate().to(URL);
         driver.manage().window().maximize();
      }
      else if (browser.equalsIgnoreCase("chrome"))
      {
         System.out.println(" Executing on CHROME");
         DesiredCapabilities cap = DesiredCapabilities.chrome();
         cap.setBrowserName("chrome");
         String Node = "http://192.168.0.101:5557/wd/hub";
         driver = new RemoteWebDriver(new URL(Node), cap);
         driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
         
         // Launch website
         driver.navigate().to(URL);
         driver.manage().window().maximize();
      }
      else
      {
         System.out.println("The Browser Type is Undefined");
      }

	  
  }
  
  
  @AfterMethod
  public void afterMethod() {
  }

}
