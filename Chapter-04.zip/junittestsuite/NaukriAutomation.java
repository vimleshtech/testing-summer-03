package junittestsuite;

import static org.junit.Assert.*;

import java.util.Set;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class NaukriAutomation {

	//Create object of webderiver 
		private static WebDriver driver=null;
		
		//will execute one time  - 1
		@BeforeClass
		public static void setUpBeforeClass() throws Exception {
		
			driver = new ChromeDriver();
			driver.get("https://www.naukri.com/");
			
		}


		//will execute one time  - 1
		@AfterClass
		public static void tearDownAfterClass() throws Exception {
		
				//close the driver /WebBrowser
				//driver.close();//close the current window of driver
				//driver.quit();//close the all associated window with current driver
				
		}

		
	@Before
	public void setUp() throws Exception {
	
		driver.get("https://www.naukri.com/");
		
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Ignore
	@Test
	public void test() {
	
		
		//close window except main page 
		Set<String> wins = 	driver.getWindowHandles();
		
		for(String win: wins) {
			
			driver.switchTo().window(win);
			
			if(!driver.getTitle().startsWith("Jobs"))
				driver.close();
			
		}
	 	
	
		wins = 	driver.getWindowHandles();
		
		Assert.assertEquals(1, wins.size());
		
		//Assert.assertEquals("wrong paws", "flkfjfghf");
			
		/*if(!true && !true && !false)
			fail("condition is not match");
		*/
		
	}
	
	
	
	@Test
	public void loginTest() {
	
		//type casting / type conversion 
		Actions act = new Actions(driver);
		
		//get reference of webelement
		WebElement el = driver.findElement(By.id("login_Layer"));
		
		//act.moveToElement(el).build().perform();
		//act.moveToElement(el).build().perform();
		//act.moveToElement(el).build().perform();
		
		act.moveToElement(el).click().build().perform();
		
		
		driver.findElement(By.id("eLoginNew")).sendKeys("vimlesh073@gmail.com");
		
		
	}
	
}
