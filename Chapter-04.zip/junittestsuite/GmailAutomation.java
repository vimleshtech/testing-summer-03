package junittestsuite;

import static org.junit.Assert.*;

import java.io.File;
import java.util.Set;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class GmailAutomation {

	//Create object of webderiver 
	private static WebDriver driver=null;
	
	//will execute one time  - 1
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	
		driver = new ChromeDriver();
		driver.get("https://www.google.com/");
		
	}


	//will execute one time  - 1
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	
			//close the driver /WebBrowser
			//driver.close();//close the current window of driver
			driver.quit();//close the all associated window with current driver
			
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
		
		//after @Test 
		//capture screen short
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		//FileHandler.copy(src,new File("E:\\Raman\\Testing\\chromedriver_win32\\gmail.png"));
		
	}

	
	@Ignore
	@Test
	public void testTryWithOtherPwd() throws InterruptedException {

		driver.findElement(By.xpath("//*[@id='password']/div[1]/div/div[1]/input")).sendKeys("alpha test");
		driver.findElement(By.id("passwordNext")).click();
	
		
		
	}
	@Test
	public void test() throws InterruptedException {

		driver.findElement(By.linkText("Gmail")).click();
		driver.findElement(By.linkText("Sign in")).click();
		
		//window handling
		Set<String> wins= driver.getWindowHandles(); //return reference all windows which is associated with current driver
		System.out.println(wins.size());
		
		for(String win : wins) {			
			driver.switchTo().window(win);
			System.out.println(driver.getTitle());
			
			if(driver.getTitle().equals("Gmail")) {
				
					break; //skip or terminate the loop 
			}
		}
		
		driver.findElement(By.id("identifierId")).sendKeys("vimlesh073");
		driver.findElement(By.id("identifierNext")).click();
	
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//*[@id='password']/div[1]/div/div[1]/input")).sendKeys("alpha test");
		driver.findElement(By.id("passwordNext")).click();
	
		Thread.sleep(5000);
		
		String msg= 	driver.findElement(By.xpath("//*[@id='view_container']/div/div/div[2]/div/div[1]/div/form/span/section/div/span/div[1]/div[2]/div[2]/span")).getText();
		
		
		System.out.println(msg);
		
	}

}
