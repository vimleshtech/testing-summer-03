package testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import utilities.BrowserStartup;


public class BuyRealChips extends BrowserStartup {

	  private WebDriver driver;
	  private String baseUrl;
	  private boolean acceptNextAlert = true;
	  private StringBuffer verificationErrors = new StringBuffer();

	  @Before
	  public void setUp() throws Exception {
	    driver = new FirefoxDriver();
	    baseUrl = "http://adda52.org/";
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  }
	
  @Test
  public void testTC0343() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("username")).click();
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("rahulshri");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("gauss123");
    driver.findElement(By.id("btn-login")).click();
    driver.findElement(By.linkText("My Account")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
    // driver.findElement(By.id("fbInspectButton")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=_e_0IcL | ]]
    try {
      assertTrue(isElementPresent(By.id("credit-card")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
    // driver.findElement(By.id("fbInspectButton")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=_e_0IcL | ]]
    try {
      assertTrue(isElementPresent(By.id("debit-card")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
    // driver.findElement(By.id("fbInspectButton")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=_e_0IcL | ]]
    try {
      assertTrue(isElementPresent(By.id("net-banking")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
    // driver.findElement(By.id("fbInspectButton")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=_e_0IcL | ]]
    try {
      assertTrue(isElementPresent(By.id("cod")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
    // driver.findElement(By.id("fbInspectButton")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=_e_0IcL | ]]
    try {
      assertTrue(isElementPresent(By.id("scratch")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
    // driver.findElement(By.id("fbInspectButton")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=_e_0IcL | ]]
    try {
      assertTrue(isElementPresent(By.xpath("//div[@id='wrapper']/section/div/article")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }

  
  @Test
  public void testTC0346() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("rahulshri");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("gauss123");
    driver.findElement(By.id("btn-login")).click();
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.cssSelector("li.active > a > span")).click();
    driver.findElement(By.id("credit-card")).click();
    driver.findElement(By.cssSelector("p > a > img")).click();
    try {
      assertEquals("The First Name field is required.", driver.findElement(By.id("my_fname_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    try {
      assertEquals("The Last Name field is required.", driver.findElement(By.id("my_lname_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    try {
      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }
  
  @Test
  public void testTC0347TC0351() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("rahulshri");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("gauss123");
    driver.findElement(By.id("btn-login")).click();
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.cssSelector("li.active > a > span")).click();
    driver.findElement(By.id("credit-card")).click();
    driver.findElement(By.id("firstname_1")).clear();
    driver.findElement(By.id("firstname_1")).sendKeys("rahul@");
    driver.findElement(By.cssSelector("p > a > img")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname_1")).clear();
    driver.findElement(By.id("firstname_1")).sendKeys("rahul#");
    driver.findElement(By.cssSelector("p > a > img")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname_1")).clear();
    driver.findElement(By.id("firstname_1")).sendKeys("123457848");
    driver.findElement(By.cssSelector("p > a > img")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname_1")).clear();
    driver.findElement(By.id("firstname_1")).sendKeys("rahul1548");
    driver.findElement(By.cssSelector("p > a > img")).click();
    driver.findElement(By.id("credit-card")).click();
    driver.findElement(By.id("firstname_1")).clear();
    driver.findElement(By.id("firstname_1")).sendKeys("r8748#");
    driver.findElement(By.cssSelector("p > a > img")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname_1")).clear();
    driver.findElement(By.id("firstname_1")).sendKeys("qawsedrftgyhujikolpqa");
    driver.findElement(By.cssSelector("p > a > img")).click();
    try {
      assertEquals("The First Name should not exceed 20 characters in length.", driver.findElement(By.id("my_fname_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }


  @Test
  public void testTC0353TC0357() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("rahulshri");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("gauss123");
    driver.findElement(By.id("btn-login")).click();
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.cssSelector("li.active > a > span")).click();
    driver.findElement(By.id("credit-card")).click();
    driver.findElement(By.id("lastname_1")).click();
    driver.findElement(By.id("lastname_1")).clear();
    driver.findElement(By.id("lastname_1")).sendKeys("rahul@@");
    driver.findElement(By.cssSelector("p > a > img")).click();
    try {
      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("lastname_1")).clear();
    driver.findElement(By.id("lastname_1")).sendKeys("##########");
    driver.findElement(By.cssSelector("p > a > img")).click();
    try {
      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("lastname_1")).clear();
    driver.findElement(By.id("lastname_1")).sendKeys("@#$ *asdwe");
    driver.findElement(By.cssSelector("p > a > img")).click();
    /* try {
        assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_1")).getText());
      } catch (Error e) {
        verificationErrors.append(e.toString());
      } */
    driver.findElement(By.id("lastname_1")).clear();
    driver.findElement(By.id("lastname_1")).sendKeys("5464654#@#$#@$");
    driver.findElement(By.cssSelector("p > a > img")).click();
    try {
      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("lastname_1")).clear();
    driver.findElement(By.id("lastname_1")).sendKeys("rahulshri1234");
    driver.findElement(By.cssSelector("p > a > img")).click();
    try {
      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }

  @Test
  public void testTC0359TC0366() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("username")).click();
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("rahulshri");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("gauss123");
    driver.findElement(By.id("btn-login")).click();
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.cssSelector("li.active > a > span")).click();
    driver.findElement(By.id("credit-card")).click();
    driver.findElement(By.id("mobile_1")).clear();
    driver.findElement(By.id("mobile_1")).sendKeys("@@@#*##");
    driver.findElement(By.cssSelector("p > a > img")).click();
    try {
      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("mobile_1")).clear();
    driver.findElement(By.id("mobile_1")).sendKeys("asdwertfds");
    driver.findElement(By.cssSelector("p > a > img")).click();
    try {
      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("mobile_1")).clear();
    driver.findElement(By.id("mobile_1")).sendKeys("123456789");
    driver.findElement(By.cssSelector("p > a > img")).click();
    try {
      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("mobile_1")).clear();
    driver.findElement(By.id("mobile_1")).sendKeys("12345678912");
    driver.findElement(By.cssSelector("p > a > img")).click();
    try {
      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("mobile_1")).clear();
    driver.findElement(By.id("mobile_1")).sendKeys("@#*$rahul");
    driver.findElement(By.cssSelector("p > a > img")).click();
    try {
      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("mobile_1")).clear();
    driver.findElement(By.id("mobile_1")).sendKeys("12345#$*dr");
    driver.findElement(By.cssSelector("p > a > img")).click();
    try {
      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_1")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }
  public void testTC0368TC0373() throws Exception {
	    driver.get(baseUrl + "/");
	    driver.findElement(By.id("username")).click();
	    driver.findElement(By.id("username")).clear();
	    driver.findElement(By.id("username")).sendKeys("rahulshri");
	    driver.findElement(By.id("password")).clear();
	    driver.findElement(By.id("password")).sendKeys("gauss123");
	    driver.findElement(By.id("btn-login")).click();
	    driver.findElement(By.linkText("My Account")).click();
	    driver.findElement(By.cssSelector("li.active > a > span")).click();
	    driver.findElement(By.id("debit-card")).click();
	    driver.findElement(By.id("firstname_2")).clear();
	    driver.findElement(By.id("firstname_2")).sendKeys("@#$&**");
	    driver.findElement(By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img")).click();
	    try {
	      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_2")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("firstname_2")).clear();
	    driver.findElement(By.id("firstname_2")).sendKeys("@*#rahul");
	    driver.findElement(By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img")).click();
	    driver.findElement(By.id("firstname_2")).clear();
	    driver.findElement(By.id("firstname_2")).sendKeys("@#*&12345");
	    driver.findElement(By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img")).click();
	    try {
	      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_2")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("firstname_2")).clear();
	    driver.findElement(By.id("firstname_2")).sendKeys("rahul123");
	    driver.findElement(By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img")).click();
	    try {
	      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_2")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("firstname_2")).clear();
	    driver.findElement(By.id("firstname_2")).sendKeys("qawsedrftgyhujikolpqa");
	    driver.findElement(By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img")).click();
	    try {
	      assertEquals("The First Name should not exceed 20 characters in length.", driver.findElement(By.id("my_fname_2")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

  public void testTC0374TC0378() throws Exception {
	    driver.get(baseUrl + "/");
	    driver.findElement(By.id("username")).clear();
	    driver.findElement(By.id("username")).sendKeys("rahulshri");
	    driver.findElement(By.id("password")).clear();
	    driver.findElement(By.id("password")).sendKeys("gauss123");
	    driver.findElement(By.id("btn-login")).click();
	    driver.findElement(By.linkText("My Account")).click();
	    driver.findElement(By.cssSelector("li.active > a > span")).click();
	    driver.findElement(By.id("debit-card")).click();
	    driver.findElement(By.id("lastname_2")).click();
	    driver.findElement(By.id("lastname_2")).clear();
	    driver.findElement(By.id("lastname_2")).sendKeys("@#$%*&");
	    driver.findElement(By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img")).click();
	    try {
	      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_2")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("lastname_2")).clear();
	    driver.findElement(By.id("lastname_2")).sendKeys("@#$*rahul");
	    driver.findElement(By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img")).click();
	    driver.findElement(By.id("lastname_2")).clear();
	    driver.findElement(By.id("lastname_2")).sendKeys("@#*$12345");
	    driver.findElement(By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img")).click();
	    try {
	      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_2")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("lastname_2")).clear();
	    driver.findElement(By.id("lastname_2")).sendKeys("rahul12345");
	    driver.findElement(By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img")).click();
	    try {
	      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_2")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("lastname_2")).clear();
	    driver.findElement(By.id("lastname_2")).sendKeys("12345rahul");
	    driver.findElement(By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img")).click();
	    driver.findElement(By.id("lastname_2")).clear();
	    driver.findElement(By.id("lastname_2")).sendKeys("qawsedrftgyhujikolpzx");
	    driver.findElement(By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img")).click();
	    try {
	      assertEquals("The Last Name should not exceed 20 characters in length.", driver.findElement(By.id("my_lname_2")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }
  public void testTC0385() throws Exception {
	    driver.get(baseUrl + "/");
	    driver.findElement(By.id("username")).click();
	    driver.findElement(By.id("username")).clear();
	    driver.findElement(By.id("username")).sendKeys("rahulshri");
	    driver.findElement(By.id("password")).clear();
	    driver.findElement(By.id("password")).sendKeys("gauss123");
	    driver.findElement(By.id("btn-login")).click();
	    driver.findElement(By.linkText("My Account")).click();
	    driver.findElement(By.cssSelector("li.active > a > span")).click();
	    driver.findElement(By.id("net-banking")).click();
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    try {
	      assertEquals("The First Name field is required.", driver.findElement(By.id("my_fname_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertEquals("The Last Name field is required.", driver.findElement(By.id("my_lname_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

  public void testTC0386TC0390() throws Exception {
	    driver.get(baseUrl + "/");
	    driver.findElement(By.id("username")).clear();
	    driver.findElement(By.id("username")).sendKeys("rahulshri");
	    driver.findElement(By.id("password")).clear();
	    driver.findElement(By.id("password")).sendKeys("gauss123");
	    driver.findElement(By.id("btn-login")).click();
	    driver.findElement(By.linkText("My Account")).click();
	    driver.findElement(By.cssSelector("li.active > a > span")).click();
	    driver.findElement(By.id("net-banking")).click();
	    driver.findElement(By.id("firstname_3")).clear();
	    driver.findElement(By.id("firstname_3")).sendKeys("@#$*&");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    try {
	      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("firstname_3")).clear();
	    driver.findElement(By.id("firstname_3")).sendKeys("@#*&$rahul");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    driver.findElement(By.id("firstname_3")).clear();
	    driver.findElement(By.id("firstname_3")).sendKeys("@#$&*12345");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    try {
	      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("firstname_3")).clear();
	    driver.findElement(By.id("firstname_3")).sendKeys("rahul12345");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    try {
	      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("firstname_3")).clear();
	    driver.findElement(By.id("firstname_3")).sendKeys("12345rahul");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    driver.findElement(By.id("firstname_3")).clear();
	    driver.findElement(By.id("firstname_3")).sendKeys("qazwsxedcrfvtgbyhnujm");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    try {
	      assertEquals("The First Name should not exceed 20 characters in length.", driver.findElement(By.id("my_fname_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }
  public void testTC0392TC0396() throws Exception {
	    driver.get(baseUrl + "/");
	    driver.findElement(By.id("username")).clear();
	    driver.findElement(By.id("username")).sendKeys("rahulshri");
	    driver.findElement(By.id("password")).clear();
	    driver.findElement(By.id("password")).sendKeys("gauss123");
	    driver.findElement(By.id("btn-login")).click();
	    driver.findElement(By.linkText("My Account")).click();
	    driver.findElement(By.cssSelector("li.active > a > span")).click();
	    driver.findElement(By.id("net-banking")).click();
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    try {
	      assertEquals("The First Name field is required.", driver.findElement(By.id("my_fname_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertEquals("The Last Name field is required.", driver.findElement(By.id("my_lname_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("lastname_3")).clear();
	    driver.findElement(By.id("lastname_3")).sendKeys("@#$&*");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    try {
	      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("lastname_3")).clear();
	    driver.findElement(By.id("lastname_3")).sendKeys("@#$&*1234");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    try {
	      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("lastname_3")).clear();
	    driver.findElement(By.id("lastname_3")).sendKeys("12345@#$*&");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    try {
	      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("lastname_3")).clear();
	    driver.findElement(By.id("lastname_3")).sendKeys("rahul12345");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    try {
	      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("lastname_3")).clear();
	    driver.findElement(By.id("lastname_3")).sendKeys("12345rahul");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    driver.findElement(By.id("lastname_3")).clear();
	    driver.findElement(By.id("lastname_3")).sendKeys("qawsedrftgyhujikolpqa");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    try {
	      assertEquals("The Last Name should not exceed 20 characters in length.", driver.findElement(By.id("my_lname_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }
  public void testTC0398TC0402() throws Exception {
	    driver.get(baseUrl + "/");
	    driver.findElement(By.id("username")).clear();
	    driver.findElement(By.id("username")).sendKeys("rahulshri");
	    driver.findElement(By.id("password")).clear();
	    driver.findElement(By.id("password")).sendKeys("gauss123");
	    driver.findElement(By.id("btn-login")).click();
	    driver.findElement(By.linkText("My Account")).click();
	    driver.findElement(By.cssSelector("li.active > a > span")).click();
	    driver.findElement(By.id("net-banking")).click();
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    try {
	      assertEquals("The First Name field is required.", driver.findElement(By.id("my_fname_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertEquals("The Last Name field is required.", driver.findElement(By.id("my_lname_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("mobile_3")).clear();
	    driver.findElement(By.id("mobile_3")).sendKeys("@#$&*");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    try {
	      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("mobile_3")).clear();
	    driver.findElement(By.id("mobile_3")).sendKeys("rahulshrivastava");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    try {
	      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("mobile_3")).clear();
	    driver.findElement(By.id("mobile_3")).sendKeys("123456789");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    try {
	      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("mobile_3")).clear();
	    driver.findElement(By.id("mobile_3")).sendKeys("12345678912");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	    try {
	      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_3")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("mobile_3")).clear();
	    driver.findElement(By.id("mobile_3")).sendKeys("1234567891");
	    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
	  }
  @Test
  public void testTC0403TC0420() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("username")).click();
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("rahulshri");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("gauss123");
    driver.findElement(By.id("btn-login")).click();
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.cssSelector("li.active > a > span")).click();
    driver.findElement(By.id("net-banking")).click();
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    try {
      assertEquals("The First Name field is required.", driver.findElement(By.id("my_fname_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    try {
      assertEquals("The Last Name field is required.", driver.findElement(By.id("my_lname_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    try {
      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname_3")).clear();
    driver.findElement(By.id("firstname_3")).sendKeys("@#$&*");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname_3")).clear();
    driver.findElement(By.id("firstname_3")).sendKeys("#$&*@rahul");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    driver.findElement(By.id("firstname_3")).clear();
    driver.findElement(By.id("firstname_3")).sendKeys("rahul@#$&*");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname_3")).clear();
    driver.findElement(By.id("firstname_3")).sendKeys("123456789");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname_3")).clear();
    driver.findElement(By.id("firstname_3")).sendKeys("rahul123");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname_3")).clear();
    driver.findElement(By.id("firstname_3")).sendKeys("123rahul");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    driver.findElement(By.id("firstname_3")).clear();
    driver.findElement(By.id("firstname_3")).sendKeys("@#$&*1234");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname_3")).clear();
    driver.findElement(By.id("firstname_3")).sendKeys("1234@#$&*");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname_3")).clear();
    driver.findElement(By.id("firstname_3")).sendKeys("rahulshr");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    driver.findElement(By.id("lastname_3")).clear();
    driver.findElement(By.id("lastname_3")).sendKeys("@#$&*");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    try {
      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("lastname_3")).clear();
    driver.findElement(By.id("lastname_3")).sendKeys("@#$&*rahu");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    driver.findElement(By.id("lastname_3")).clear();
    driver.findElement(By.id("lastname_3")).sendKeys("rahu@#$&*");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    try {
      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("lastname_3")).clear();
    driver.findElement(By.id("lastname_3")).sendKeys("123456");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    try {
      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("lastname_3")).clear();
    driver.findElement(By.id("lastname_3")).sendKeys("rahul123");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    try {
      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("lastname_3")).clear();
    driver.findElement(By.id("lastname_3")).sendKeys("123rahul");
    // ERROR: Caught exception [ERROR: Unsupported command [waitForPopUp | PlayNow | 30000]]
    try {
      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("lastname_3")).clear();
    driver.findElement(By.id("lastname_3")).sendKeys("shrivas");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    driver.findElement(By.id("mobile_3")).clear();
    driver.findElement(By.id("mobile_3")).sendKeys("@#$&*");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    try {
      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("mobile_3")).clear();
    driver.findElement(By.id("mobile_3")).sendKeys("rahul123");
    try {
      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("mobile_3")).clear();
    driver.findElement(By.id("mobile_3")).sendKeys("123rahuls");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    try {
      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("mobile_3")).clear();
    driver.findElement(By.id("mobile_3")).sendKeys("1234567");
    driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
    try {
      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("mobile_3")).clear();
    driver.findElement(By.id("mobile_3")).sendKeys("12345678941");
    try {
      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_3")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }
  public void testTC0421TC0423() throws Exception {
	    driver.get(baseUrl + "/");
	    driver.findElement(By.id("username")).clear();
	    driver.findElement(By.id("username")).sendKeys("rahulshri");
	    driver.findElement(By.id("password")).clear();
	    driver.findElement(By.id("password")).sendKeys("gauss123");
	    driver.findElement(By.id("btn-login")).click();
	    driver.findElement(By.linkText("My Account")).click();
	    driver.findElement(By.cssSelector("li.active > a > span")).click();
	    driver.findElement(By.id("credit-card")).click();
	    driver.findElement(By.id("firstname_1")).clear();
	    driver.findElement(By.id("firstname_1")).sendKeys("rahultest");
	    driver.findElement(By.id("lastname_1")).clear();
	    driver.findElement(By.id("lastname_1")).sendKeys("testrahuls");
	    driver.findElement(By.id("mobile_1")).clear();
	    driver.findElement(By.id("mobile_1")).sendKeys("9898989898");
	    driver.findElement(By.cssSelector("p > a > img")).click();
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='credit-card-1']")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='move']/div/div[3]")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='credit-card-1']/div[2]/div[2]/div[2]/a/img")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("btn-continue")).click();
	    try {
	      assertEquals("The First Name field is required.", driver.findElement(By.id("my_fname_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertEquals("The Last Name field is required.", driver.findElement(By.id("my_lname_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }
  public void testTC0424TC0445() throws Exception {
	    driver.get(baseUrl + "/");
	    driver.findElement(By.id("username")).click();
	    driver.findElement(By.id("username")).clear();
	    driver.findElement(By.id("username")).sendKeys("rahulshri");
	    driver.findElement(By.id("password")).clear();
	    driver.findElement(By.id("password")).sendKeys("gauss123");
	    driver.findElement(By.id("btn-login")).click();
	    driver.findElement(By.linkText("My Account")).click();
	    driver.findElement(By.cssSelector("li.active > a > span")).click();
	    driver.findElement(By.id("credit-card")).click();
	    driver.findElement(By.id("firstname_1")).click();
	    driver.findElement(By.id("firstname_1")).clear();
	    driver.findElement(By.id("firstname_1")).sendKeys("rahultest");
	    driver.findElement(By.id("lastname_1")).clear();
	    driver.findElement(By.id("lastname_1")).sendKeys("testa");
	    driver.findElement(By.id("mobile_1")).clear();
	    driver.findElement(By.id("mobile_1")).sendKeys("8989898989");
	    driver.findElement(By.cssSelector("p > a > img")).click();
	    driver.findElement(By.id("firstname_5")).clear();
	    driver.findElement(By.id("firstname_5")).sendKeys("@#$&*");
	    driver.findElement(By.id("btn-continue")).click();
	    try {
	      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("firstname_5")).clear();
	    driver.findElement(By.id("firstname_5")).sendKeys("@#*rtest");
	    driver.findElement(By.id("btn-continue")).click();
	    driver.findElement(By.id("firstname_5")).clear();
	    driver.findElement(By.id("firstname_5")).sendKeys("rtest@#*");
	    driver.findElement(By.id("btn-continue")).click();
	    try {
	      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("firstname_5")).clear();
	    driver.findElement(By.id("firstname_5")).sendKeys("rtest1234");
	    driver.findElement(By.id("btn-continue")).click();
	    try {
	      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("firstname_5")).clear();
	    driver.findElement(By.id("firstname_5")).sendKeys("qawsedrftgyhujikolpqa");
	    driver.findElement(By.id("btn-continue")).click();
	    try {
	      assertEquals("The First Name should not exceed 20 characters in length.", driver.findElement(By.id("my_fname_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("firstname_5")).clear();
	    driver.findElement(By.id("firstname_5")).sendKeys("rtesta");
	    driver.findElement(By.id("btn-continue")).click();
	    driver.findElement(By.id("lastname_5")).clear();
	    driver.findElement(By.id("lastname_5")).sendKeys("@#&*");
	    driver.findElement(By.id("btn-continue")).click();
	    try {
	      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("lastname_5")).clear();
	    driver.findElement(By.id("lastname_5")).sendKeys("@#&*+rtestb");
	    driver.findElement(By.id("btn-continue")).click();
	    driver.findElement(By.id("lastname_5")).clear();
	    driver.findElement(By.id("lastname_5")).sendKeys("rtestb@#*");
	    driver.findElement(By.id("btn-continue")).click();
	    try {
	      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("lastname_5")).clear();
	    driver.findElement(By.id("lastname_5")).sendKeys("testa");
	    driver.findElement(By.id("btn-continue")).click();
	    driver.findElement(By.id("mobile_5")).clear();
	    driver.findElement(By.id("mobile_5")).sendKeys("@#&*");
	    driver.findElement(By.id("btn-continue")).click();
	    try {
	      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("mobile_5")).clear();
	    driver.findElement(By.id("mobile_5")).sendKeys("@#$&*123");
	    driver.findElement(By.id("btn-continue")).click();
	    try {
	      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("mobile_5")).clear();
	    driver.findElement(By.id("mobile_5")).sendKeys("1234567");
	    driver.findElement(By.id("btn-continue")).click();
	    try {
	      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("mobile_5")).clear();
	    driver.findElement(By.id("mobile_5")).sendKeys("1");
	    driver.findElement(By.id("btn-continue")).click();
	    try {
	      assertEquals("Enter a valid mobile no.", driver.findElement(By.id("my_mob_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("mobile_5")).clear();
	    driver.findElement(By.id("mobile_5")).sendKeys("7897897897");
	    driver.findElement(By.id("btn-continue")).click();
	    driver.findElement(By.id("address_5")).clear();
	    driver.findElement(By.id("address_5")).sendKeys("Delhi6");
	    driver.findElement(By.id("btn-continue")).click();
	    driver.findElement(By.id("city_5")).clear();
	    driver.findElement(By.id("city_5")).sendKeys("789456");
	    driver.findElement(By.id("btn-continue")).click();
	    try {
	      assertEquals("Enter a valid city name.", driver.findElement(By.id("my_city_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("city_5")).clear();
	    driver.findElement(By.id("city_5")).sendKeys("delhi6");
	    driver.findElement(By.id("btn-continue")).click();
	    try {
	      assertEquals("Enter a valid city name.", driver.findElement(By.id("my_city_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("city_5")).clear();
	    driver.findElement(By.id("city_5")).sendKeys("delhi");
	    driver.findElement(By.id("btn-continue")).click();
	    driver.findElement(By.id("pincode_5")).clear();
	    driver.findElement(By.id("pincode_5")).sendKeys("@#$&*");
	    driver.findElement(By.id("btn-continue")).click();
	    try {
	      assertEquals("Enter a valid Pin Code.", driver.findElement(By.id("my_pin_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("pincode_5")).clear();
	    driver.findElement(By.id("pincode_5")).sendKeys("testb");
	    driver.findElement(By.id("btn-continue")).click();
	    try {
	      assertEquals("Enter a valid Pin Code.", driver.findElement(By.id("my_pin_5")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("pincode_5")).clear();
	    driver.findElement(By.id("pincode_5")).sendKeys("testb987");
	    driver.findElement(By.id("btn-continue")).click();
	    driver.findElement(By.id("pincode_5")).clear();
	    driver.findElement(By.id("pincode_5")).sendKeys("123456");
	    driver.findElement(By.id("btn-continue")).click();
	    new Select(driver.findElement(By.id("state_5"))).selectByVisibleText("DELHI");
	    driver.findElement(By.xpath("//div[@id='credit-card-1']/div[2]/div[2]/div[2]/a/img")).click();
	    driver.findElement(By.id("address_5")).clear();
	    driver.findElement(By.id("address_5")).sendKeys("testb");
	    driver.findElement(By.id("city_5")).clear();
	    driver.findElement(By.id("city_5")).sendKeys("testb");
	    driver.findElement(By.id("pincode_5")).clear();
	    driver.findElement(By.id("pincode_5")).sendKeys("123455");
	    new Select(driver.findElement(By.id("state_5"))).selectByVisibleText("DELHI");
	    driver.findElement(By.id("btn-continue")).click();
	    try {
	      assertEquals("Card Type", driver.findElement(By.cssSelector("label")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertEquals("Amount", driver.findElement(By.cssSelector("#buy_chips_amount > div.formbuychips > label")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertEquals("Bonus Code", driver.findElement(By.xpath("//div[@id='buy_chips_amount']/div[3]/label")).getText());
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
