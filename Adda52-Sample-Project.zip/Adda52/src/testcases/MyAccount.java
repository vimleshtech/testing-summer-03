package testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import utilities.BrowserStartup;

  public class MyAccount extends BrowserStartup {
	  
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://adda52.org/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testTC0161() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("username")).click();
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("rahulsh");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("gauss123");
    driver.findElement(By.id("btn-login")).click();
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.cssSelector("a > span")).click();
    driver.get(baseUrl + "/my-account");
  }
  
  public void testTC0162() throws Exception {
	    driver.get(baseUrl + "/");
	    driver.findElement(By.linkText("Adda52.com")).click();
	    driver.findElement(By.id("username")).clear();
	    driver.findElement(By.id("username")).sendKeys("rahulsh");
	    driver.findElement(By.id("password")).click();
	    driver.findElement(By.id("password")).clear();
	    driver.findElement(By.id("password")).sendKeys("gauss123");
	    driver.findElement(By.id("btn-login")).click();
	    driver.findElement(By.linkText("My Account")).click();
	    driver.findElement(By.cssSelector("a > span")).click();
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='profileInfo']/div/div[2]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='profileInfo']/div/div[3]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='profileInfo']/div/div[4]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='profileInfo']/div/div[5]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='profileInfo']/div/div[6]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='profileInfo']/div/div[7]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='profileInfo']/div/div[8]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='profileInfo']/div/div[9]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='profileInfo']/div/div[10]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='profileInfo']/div/div[11]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='profileInfo']/div/div[12]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//form[@id='profileInfo']/div/div[13]/label")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	  }

  @Test
  public void testTC0163() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("username")).click();
    driver.findElement(By.id("username")).click();
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("rahulshri");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("gauss123");
    driver.findElement(By.id("btn-login")).click();
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.cssSelector("a > span")).click();
    driver.findElement(By.xpath("//*[@id='profileInfo']/div/div[5]"));
 
    // To verify Email field is disabled
    if (driver.findElement(By.xpath("//*[@id='profileInfo']/div/div[5]")).isSelected())
    {
    	driver.findElement(By.xpath("//*[@id='profileInfo']/div/div[5]")).sendKeys("ABC");
    	System.out.println("Email Is Enabled and Editable");
    }
    else
    {
    	System.out.println("Email is Disabled");
    }
    
    // To verify Gender field is disabled
    if (driver.findElement(By.xpath("//*[@id='profileInfo']/div/div[6]")).isSelected())
    {
    	driver.findElement(By.xpath("//*[@id='profileInfo']/div/div[6]")).sendKeys("ABC");
    	System.out.println("Gender Is Enabled and Editable");
    }
    else
    {
    	System.out.println("Gender is Disabled");
    }
    
    // To verify Birth Year field is disabled
    if (driver.findElement(By.xpath("//*[@id='profileInfo']/div/div[7]")).isSelected())
    {
    	driver.findElement(By.xpath("//*[@id='profileInfo']/div/div[7]")).sendKeys("ABC");
    	System.out.println("Birht Year Is Enabled and Editable");
    }
    else
    {
    	System.out.println("Birth Year is Disabled");
    }
    
    
    }

  @Test
  public void testTC0164_TC0168() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("rahulshri");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("gauss123");
    driver.findElement(By.id("btn-login")).click();
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.cssSelector("a > span")).click();
    // driver.findElement(By.id("firstname")).clear();
    driver.findElement(By.id("firstname")).sendKeys("rahulshri@");
    driver.findElement(By.id("btn-save")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
    // driver.findElement(By.id("fbInspectButton")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | null | ]]
    try {
      assertEquals("The First Name field may only contain alphabetical characters.", driver.findElement(By.id("my_fname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname")).sendKeys("rahulshri#");
    driver.findElement(By.id("btn-save")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
    // driver.findElement(By.id("fbInspectButton")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | null | ]]
    try {
      assertEquals("The First Name field may only contain alphabetical characters.", driver.findElement(By.id("my_fname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname")).clear();
    driver.findElement(By.id("firstname")).sendKeys("rahulshri*");
    driver.findElement(By.id("btn-save")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
    // driver.findElement(By.id("fbInspectButton")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | null | ]]
    try {
      assertEquals("The First Name field may only contain alphabetical characters.", driver.findElement(By.id("my_fname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname")).clear();
    driver.findElement(By.id("firstname")).sendKeys("qawsedrftgyhujikolpqa");
    driver.findElement(By.id("btn-save")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
    // driver.findElement(By.id("fbInspectButton")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | null | ]]
    try {
      assertEquals("The First Name field can not exceed 20 characters in length.", driver.findElement(By.id("my_fname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }


  @Test
  public void testUntitled() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("username")).click();
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("rahulshri");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("gauss123");
    driver.findElement(By.id("btn-login")).click();
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.cssSelector("a > span")).click();
    driver.findElement(By.id("lastname")).clear();
    driver.findElement(By.id("lastname")).sendKeys("test#");
    driver.findElement(By.id("btn-save")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
    // driver.findElement(By.id("fbInspectButton")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | null | ]]
    try {
      assertEquals("The Last Name field may only contain alphabetical characters.", driver.findElement(By.id("my_lname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("lastname")).clear();
    driver.findElement(By.id("lastname")).sendKeys("test@");
    driver.findElement(By.id("btn-save")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
    // driver.findElement(By.id("fbInspectButton")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | null | ]]
    try {
      assertEquals("The Last Name field may only contain alphabetical characters.", driver.findElement(By.id("my_lname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("lastname")).clear();
    driver.findElement(By.id("lastname")).sendKeys("test*");
    driver.findElement(By.id("btn-save")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
    // driver.findElement(By.id("fbInspectButton")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | null | ]]
    try {
      assertEquals("The Last Name field may only contain alphabetical characters.", driver.findElement(By.id("my_lname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("lastname")).clear();
    driver.findElement(By.id("lastname")).sendKeys("test12");
    driver.findElement(By.id("btn-save")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=fbMainContainer | ]]
    // driver.findElement(By.id("fbInspectButton")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | null | ]]
    try {
      assertEquals("The Last Name field may only contain alphabetical characters.", driver.findElement(By.id("my_lname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }

  @Test
  public void testTC0176_TC0183() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("username")).click();
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("rahulshri");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("gauss123");
    driver.findElement(By.id("btn-login")).click();
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.cssSelector("a > span")).click();
    try {
    	Thread.sleep(2000);
      assertTrue(isElementPresent(By.id("testclick1")));
        } catch (Error e) {
      verificationErrors.append(e.toString());
    }
        driver.findElement(By.cssSelector("strong")).click();
        String myWindowHandle = driver.getWindowHandle();
        driver.switchTo().window(myWindowHandle);
        driver.findElement(By.xpath("//*[@id='tinycontent']/div[2]"));
        driver.findElement(By.xpath("//*[@id='tinycontent']/div[1]/div[1]"));
        driver.findElement(By.xpath("//*[@id='tinycontent']/div[1]/div[2]/a"));
        driver.findElement(By.xpath("//*[@id='mobile']/div[2]/label"));
        driver.findElement(By.xpath("//*[@id='mobile']"));
        driver.findElement(By.xpath("//*[@id='btn-save']"));
        driver.findElement(By.xpath("//*[@id='mobile']")).sendKeys("@#$*484545");
        driver.findElement(By.xpath("(//input[@id='btn-save'])[2]")).click();
        try {
          assertEquals("Invalid mobile number.", driver.findElement(By.id("mobile_err")).getText());
        } catch (Error e) {
          verificationErrors.append(e.toString());
        }
        
       
  }

  @Test
  public void testPopUp() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("username")).click();
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("rahulshri");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("gauss123");
    driver.findElement(By.id("btn-login")).click();
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.cssSelector("a > span")).click();
    try {
    	Thread.sleep(2000);
      assertTrue(isElementPresent(By.id("testclick1")));
        } catch (Error e) {
      verificationErrors.append(e.toString());
    }
        driver.findElement(By.cssSelector("strong")).click();
        String myWindowHandle = driver.getWindowHandle();
        driver.switchTo().window(myWindowHandle);
        driver.findElement(By.xpath("//*[@id='tinycontent']/div[2]"));
        driver.findElement(By.xpath("//*[@id='tinycontent']/div[1]/div[1]"));
        driver.findElement(By.xpath("//*[@id='tinycontent']/div[1]/div[2]/a"));
        driver.findElement(By.xpath("//*[@id='mobile']/div[2]/label"));
        driver.findElement(By.xpath("//*[@id='mobile']"));
        driver.findElement(By.xpath("//*[@id='btn-save']"));
        WebElement PopUp = driver.findElement(By.xpath("//*[@id='mobile']"));
        PopUp.sendKeys("7897897897");
       
  }

  @Test
  public void testTC0184() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("rahulshri");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("gauss123");
    driver.findElement(By.id("btn-login")).click();
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.cssSelector("a > span")).click();
    driver.findElement(By.cssSelector("strong")).click();
    // ERROR: Caught exception [Error: Dom locators are not implemented yet!]
    driver.findElement(By.xpath("(//input[@id='btn-save'])[2]")).click();
    try {
      assertEquals("Mobile already exists, please use a different one.", driver.findElement(By.id("mobile_err")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }

  @Test
  public void testTC0186() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("rahulshri");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("gauss123");
    driver.findElement(By.id("btn-login")).click();
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.cssSelector("a > span")).click();
    driver.findElement(By.cssSelector("strong")).click();
    // ERROR: Caught exception [Error: Dom locators are not implemented yet!]
    driver.findElement(By.xpath("(//input[@id='btn-save'])[2]")).click();
    try {
      assertTrue(isElementPresent(By.id("tinybox")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }

  

  @Test
  public void testTC0192() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.linkText("Adda52.com")).click();
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("rahulshri");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("gauss123");
    driver.findElement(By.id("btn-login")).click();
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.cssSelector("a > span")).click();
    try {
      assertTrue(isElementPresent(By.name("userfile")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }


  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
