package startup;

import databaseconnection.DbConnection;

public class Caller {
	

	 private static final String tr = null;

	public static void main(String[] args) throws Exception
		   {

		 	String uname,pwd;
		 	uname = "rohitsh";
		 	pwd = "root";
		 	String usermsg = "User Name already exists. Please use a different one.";
		 	
		 	DbConnection objConn = new DbConnection();
		 	int outF = objConn.validateSignUp(uname, pwd);
		 	
		 	//Test Case 10
			TC0010 obj10 = new TC0010();
			try {
				obj10.setUp();
			//	obj10.testUntitled();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		 	
		 	if(outF == 1 && usermsg == tr)
		 	{
		 		System.out.println("Entered user already exist");
		 	}
		 	else
		 	{
		 		System.out.println("user doesn't exsit");
		 	}
		 	
		 	
		 	
		 	Untitled2 oU = new Untitled2();
		 	oU.setUp();
		 	oU.testUntitled2();
		 	
		 	
		 /*
		//Test Case 1
			TC0001 obj1 = new TC0001();
			try {
				obj1.setUp();
				obj1.testTC0001();
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
				}
		//Test Case 3
			TC0003 obj3 = new TC0003();
			try {
				obj3.setUp();
				obj3.testTC0003();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 5
			TC0005 obj5 = new TC0005();
			try {
				obj5.setUp();
				obj5.testTC0005();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 7
			TC0007 obj7 = new TC0007();
			try {
				obj7.setUp();
				obj7.testTC0007();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 8
			TC0008 obj8 = new TC0008();
			try {
				obj8.setUp();
				obj8.testTC0008();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 9
			TC0009 obj9 = new TC0009();
			try {
				obj9.setUp();
				obj9.testTC0009();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 10
			TC0010 obj10 = new TC0010();
			try {
				obj10.setUp();
				obj10.testTC0010();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 11
			TC0011 obj11 = new TC0011();
			try {
				obj11.setUp();
				obj11.testTC0011();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 12
			TC0012 obj12 = new TC0012();
			try {
				obj12.setUp();
				obj12.testTC0012();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 15
			TC0015 obj15 = new TC0015 ();
			try {
				obj15.setUp();
				obj15.testTC0015();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 16
			TC0016 obj16 = new TC0016();
			try {
				obj16.setUp();
				obj16.testTC0016();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 17
			TC0017 obj17 = new TC0017();
			try {
				obj17.setUp();
				obj17.testTC0017();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 18
			TC0018 obj18 = new TC0018();
			try {
				obj18.setUp();
				obj18.testTC0018();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 19
			TC0019 obj19 = new TC0019();
			try {
				obj19.setUp();
				obj19.testTC0019();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 20
			TC0020 obj20 = new TC0020();
			try {
				obj20.setUp();
				obj20.testTC0020();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 22
			TC0022 obj22 = new TC0022();
			try {
				obj22.setUp();
				obj22.testTC0022();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 23
			TC0023 obj23 = new TC0023();
			try {
				obj23.setUp();
				obj23.testTC0023();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 25
			TC0025 obj25 = new TC0025();
			try {
				obj25.setUp();
				obj25.testTC0025();
			}
			catch (Exception e){
				e.printStackTrace();
			}
		//Test Case 27
			TC0027 obj27 = new TC0027();
			try {
				obj27.setUp();
				obj27.testTC0027();
			}
			catch (Exception e){
				e.printStackTrace();
			}
			*/
		   }

	public static void start() {
		// TODO Auto-generated method stub
		
	}
}
			
		
		   

			
			
			
		   

					

                	


