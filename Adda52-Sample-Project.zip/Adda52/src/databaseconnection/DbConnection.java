package databaseconnection;

import java.sql.DriverManager;
import java.sql.Driver;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mysql.jdbc.Connection;

public class DbConnection {
	
	
	public int validateSignUp(String uname, String password)
	{		
		int f = 0; // 0 for not exist, 1 for exist
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1/adda52","root","root");
			Statement st = conn.createStatement();
			
			String strOut = "select * from user_info where user_name =  '"+uname +"' and password = '"+password +"'";
			
			ResultSet rs =  st.executeQuery(strOut ); //select
			
			while( rs.next())
			{	
				f = 1;				
			}
			
			
		}	
		catch (Exception e) {
			// TODO: handle exception
			f = 2; // 2 technical error
			
			System.out.println(e.toString());
		}
		
		return f;
	}

}
