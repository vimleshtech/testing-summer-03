package example;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class Startup {

	public static void main(String[] args) throws IOException {

		//Create an object of ChromeDriver class
		
		WebDriver driver = new ChromeDriver();
		System.out.println("please wait...");
		driver.get("https://www.yahoo.com/");
		
		//get title 
		String title = driver.getTitle();
		System.out.println(title);
		
		//get url 
		String url = driver.getCurrentUrl();
		System.out.println(url);
		
		
		//find one a  (anchor) tag 
		WebElement el=	driver.findElement(By.tagName("a"));
		System.out.println(el.getText());
		
		
		//Click event 
		//driver.findElement(By.linkText("News")).click();
		
		//title = driver.getTitle();
		//System.out.println(title);
		
		//find all a tags 
		List<WebElement> els =	driver.findElements(By.tagName("a"));
		
		System.out.println(els.size()); //count of  a tags
		
		for(WebElement e: els) {
			System.out.println(e.getText());
		}
		
		//TakeScreenshot
		
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(src,  new File( "E:\\Raman\\Testing\\chromedriver_win32\\test.png"));
		
		
		
		
		
	}

}
